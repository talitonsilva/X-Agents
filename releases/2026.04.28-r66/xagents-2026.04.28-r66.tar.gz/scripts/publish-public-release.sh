#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
VERSION="$(cat "$SRC_DIR/VERSION")"
PUBLIC_REPO_URL="${XPANEL_PUBLIC_REPO_URL:-https://github.com/talitonsilva/X-Agents.git}"
PUBLIC_README_SOURCE="${XPANEL_PUBLIC_README_SOURCE:-$SRC_DIR/PUBLIC_REPO_README.md}"
DIST_DIR="$SRC_DIR/release/dist/$VERSION"
PUB_DIR="$(mktemp -d /tmp/xagents-public-release.XXXXXX)"
API_TMP_DIR="$(mktemp -d /tmp/xagents-public-release-api.XXXXXX)"
SYNC_ALL_LOCAL_RELEASES="${XPANEL_SYNC_ALL_LOCAL_RELEASES:-1}"

cleanup() {
  rm -rf "$PUB_DIR"
  rm -rf "$API_TMP_DIR"
}

trap cleanup EXIT

json_field() {
  local file="$1"
  local expr="$2"
  node -e '
    const fs = require("fs");
    const file = process.argv[1];
    const expr = process.argv[2];
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    const value = expr.split(".").reduce((acc, key) => (acc && key ? acc[key] : acc), data);
    if (value === undefined || value === null) process.exit(1);
    if (typeof value === "object") {
      process.stdout.write(JSON.stringify(value));
    } else {
      process.stdout.write(String(value));
    }
  ' "$file" "$expr"
}

resolve_repo_slug() {
  local url="$1"
  local normalized="${url%.git}"
  normalized="${normalized#git@github.com:}"
  normalized="${normalized#https://github.com/}"
  normalized="${normalized#http://github.com/}"
  if [[ "$normalized" != */* ]]; then
    echo "[ERRO] Nao foi possivel extrair owner/repo de $url"
    exit 1
  fi
  printf '%s' "$normalized"
}

resolve_github_token() {
  local helper_repo_slug
  helper_repo_slug="$(resolve_repo_slug "$PUBLIC_REPO_URL" 2>/dev/null || true)"
  if [[ -n "${XPANEL_GITHUB_TOKEN:-}" ]]; then
    printf '%s' "$XPANEL_GITHUB_TOKEN"
    return 0
  fi
  if [[ -n "${GITHUB_TOKEN:-}" ]]; then
    printf '%s' "$GITHUB_TOKEN"
    return 0
  fi
  if [[ -n "${GH_TOKEN:-}" ]]; then
    printf '%s' "$GH_TOKEN"
    return 0
  fi
  local credential_output
  credential_output="$(printf 'protocol=https\nhost=github.com\n\n' | git credential fill 2>/dev/null || true)"
  local token
  token="$(printf '%s\n' "$credential_output" | awk -F= '/^password=/{print $2; exit}')"
  if [[ -n "$token" ]]; then
    printf '%s' "$token"
    return 0
  fi
  if token="$(node "$SRC_DIR/scripts/resolve-xpanel-github-token.js" "$helper_repo_slug" 2>/dev/null || true)" && [[ -n "$token" ]]; then
    printf '%s' "$token"
    return 0
  fi
  return 1
}

build_git_auth_header() {
  printf 'AUTHORIZATION: basic %s' "$(printf 'x-access-token:%s' "$1" | base64 | tr -d '\n')"
}

git_with_auth() {
  git -c "http.extraheader=$GIT_AUTH_HEADER" "$@"
}

github_api_request() {
  local method="$1"
  local url="$2"
  local output_file="$3"
  local data_file="${4:-}"
  local content_type="${5:-application/json}"
  local http_code
  if [[ -n "$data_file" ]]; then
    http_code="$(
      curl -sS \
        -X "$method" \
        -H "Authorization: Bearer $GITHUB_TOKEN_VALUE" \
        -H "Accept: application/vnd.github+json" \
        -H "X-GitHub-Api-Version: 2022-11-28" \
        -H "Content-Type: $content_type" \
        --data-binary "@$data_file" \
        -o "$output_file" \
        -w "%{http_code}" \
        "$url"
    )"
  else
    http_code="$(
      curl -sS \
        -X "$method" \
        -H "Authorization: Bearer $GITHUB_TOKEN_VALUE" \
        -H "Accept: application/vnd.github+json" \
        -H "X-GitHub-Api-Version: 2022-11-28" \
        -o "$output_file" \
        -w "%{http_code}" \
        "$url"
    )"
  fi
  printf '%s' "$http_code"
}

delete_release_asset_if_exists() {
  local release_json="$1"
  local asset_name="$2"
  local asset_id
  asset_id="$(
    node -e '
      const fs = require("fs");
      const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
      const assetName = process.argv[2];
      const asset = Array.isArray(data.assets) ? data.assets.find((item) => item && item.name === assetName) : null;
      if (asset && asset.id) process.stdout.write(String(asset.id));
    ' "$release_json" "$asset_name"
  )"
  if [[ -z "$asset_id" ]]; then
    return 0
  fi
  local delete_out="$API_TMP_DIR/delete-${asset_id}.json"
  local delete_code
  delete_code="$(github_api_request DELETE "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases/assets/$asset_id" "$delete_out")"
  if [[ "$delete_code" != "204" ]]; then
    echo "[ERRO] Falha ao remover asset antigo $asset_name da release $VERSION"
    cat "$delete_out"
    exit 1
  fi
}

upload_release_asset() {
  local release_json="$1"
  local file_path="$2"
  local asset_name
  asset_name="$(basename "$file_path")"
  delete_release_asset_if_exists "$release_json" "$asset_name"
  local upload_url
  upload_url="$(json_field "$release_json" "upload_url")"
  upload_url="${upload_url%\{*}"
  upload_url="${upload_url}?name=${asset_name}"
  local mime_type="application/octet-stream"
  case "$asset_name" in
    *.json) mime_type="application/json" ;;
    *.sh) mime_type="text/x-shellscript" ;;
    *.tar.gz) mime_type="application/gzip" ;;
  esac
  local upload_out="$API_TMP_DIR/upload-${asset_name}.json"
  local upload_code
  upload_code="$(github_api_request POST "$upload_url" "$upload_out" "$file_path" "$mime_type")"
  if [[ "$upload_code" != "201" ]]; then
    echo "[ERRO] Falha ao subir asset $asset_name para a release $VERSION"
    cat "$upload_out"
    exit 1
  fi
}

create_or_update_github_release() {
  local release_get_out="$API_TMP_DIR/release-get.json"
  local get_code
  get_code="$(github_api_request GET "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases/tags/$VERSION" "$release_get_out")"

  if [[ "$get_code" == "404" ]]; then
    local create_payload="$API_TMP_DIR/release-create.json"
    cat > "$create_payload" <<EOF
{
  "tag_name": "$VERSION",
  "target_commitish": "main",
  "name": "$VERSION",
  "body": "Release publica automatica $VERSION\\n\\nAssets:\\n- xagents-$VERSION.tar.gz\\n- install.sh\\n- manifest.json",
  "draft": false,
  "prerelease": false,
  "generate_release_notes": false
}
EOF
    local create_out="$API_TMP_DIR/release-create.out.json"
    local create_code
    create_code="$(github_api_request POST "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases" "$create_out" "$create_payload")"
    if [[ "$create_code" != "201" ]]; then
      echo "[ERRO] Falha ao criar GitHub Release $VERSION"
      cat "$create_out"
      exit 1
    fi
    cp "$create_out" "$release_get_out"
  elif [[ "$get_code" != "200" ]]; then
    echo "[ERRO] Falha ao consultar GitHub Release $VERSION"
    cat "$release_get_out"
    exit 1
  else
    local release_id
    release_id="$(json_field "$release_get_out" "id")"
    local update_payload="$API_TMP_DIR/release-update.json"
    cat > "$update_payload" <<EOF
{
  "tag_name": "$VERSION",
  "target_commitish": "main",
  "name": "$VERSION",
  "body": "Release publica automatica $VERSION\\n\\nAssets:\\n- xagents-$VERSION.tar.gz\\n- install.sh\\n- manifest.json",
  "draft": false,
  "prerelease": false,
  "make_latest": "true"
}
EOF
    local update_out="$API_TMP_DIR/release-update.out.json"
    local update_code
    update_code="$(github_api_request PATCH "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases/$release_id" "$update_out" "$update_payload")"
    if [[ "$update_code" != "200" ]]; then
      echo "[ERRO] Falha ao atualizar GitHub Release $VERSION"
      cat "$update_out"
      exit 1
    fi
    cp "$update_out" "$release_get_out"
  fi

  upload_release_asset "$release_get_out" "$DIST_DIR/xagents-$VERSION.tar.gz"
  upload_release_asset "$release_get_out" "$DIST_DIR/install.sh"
  upload_release_asset "$release_get_out" "$DIST_DIR/manifest.json"
  upload_release_asset "$release_get_out" "$DIST_DIR/integrity.json"
}

sync_release_version_dir() {
  local version_dir="$1"
  local version_name
  version_name="$(basename "$version_dir")"
  local archive_path="$version_dir/xagents-$version_name.tar.gz"
  local install_path="$version_dir/install.sh"
  local manifest_path="$version_dir/manifest.json"
  local integrity_path="$version_dir/integrity.json"
  if [[ ! -f "$archive_path" || ! -f "$install_path" || ! -f "$manifest_path" || ! -f "$integrity_path" ]]; then
    return 0
  fi
  mkdir -p "$PUB_DIR/releases/$version_name"
  cp "$archive_path" "$PUB_DIR/releases/$version_name/"
  cp "$install_path" "$PUB_DIR/releases/$version_name/"
  cp "$manifest_path" "$PUB_DIR/releases/$version_name/"
  cp "$integrity_path" "$PUB_DIR/releases/$version_name/"
}

if [[ ! -f "$DIST_DIR/xagents-$VERSION.tar.gz" ]]; then
  echo "[ERRO] Artefato nao encontrado: $DIST_DIR/xagents-$VERSION.tar.gz"
  exit 1
fi

if [[ ! -f "$DIST_DIR/install.sh" || ! -f "$DIST_DIR/manifest.json" || ! -f "$DIST_DIR/integrity.json" ]]; then
  echo "[ERRO] Release incompleta em $DIST_DIR"
  exit 1
fi

PUBLIC_REPO_SLUG="$(resolve_repo_slug "$PUBLIC_REPO_URL")"
GITHUB_TOKEN_VALUE="$(resolve_github_token || true)"
if [[ -z "$GITHUB_TOKEN_VALUE" ]]; then
  echo "[ERRO] Token GitHub nao encontrado. Defina XPANEL_GITHUB_TOKEN, GITHUB_TOKEN ou GH_TOKEN, ou configure git credential fill para github.com"
  exit 1
fi
GIT_AUTH_HEADER="$(build_git_auth_header "$GITHUB_TOKEN_VALUE")"

git_with_auth clone "$PUBLIC_REPO_URL" "$PUB_DIR"
cd "$PUB_DIR"
git checkout -B main origin/main || git checkout -B main

mkdir -p "$PUB_DIR/releases"
find "$PUB_DIR" -maxdepth 1 -type f -name 'xagents-*.tar.gz' -delete
rm -f "$PUB_DIR/install.sh" "$PUB_DIR/manifest.json" "$PUB_DIR/integrity.json"

if [[ "$SYNC_ALL_LOCAL_RELEASES" == "1" ]]; then
  while IFS= read -r version_dir; do
    sync_release_version_dir "$version_dir"
  done < <(find "$SRC_DIR/release/dist" -mindepth 1 -maxdepth 1 -type d | sort)
else
  sync_release_version_dir "$DIST_DIR"
fi

cp "$DIST_DIR/xagents-$VERSION.tar.gz" "$PUB_DIR/"
cp "$DIST_DIR/install.sh" "$PUB_DIR/"
cp "$DIST_DIR/manifest.json" "$PUB_DIR/"
cp "$DIST_DIR/integrity.json" "$PUB_DIR/"

if [[ -f "$PUBLIC_README_SOURCE" ]]; then
  cp "$PUBLIC_README_SOURCE" "$PUB_DIR/README.md"
fi

git add -A
if git diff --cached --quiet; then
  echo "[INFO] Repo publico ja estava sincronizado para $VERSION"
else
  git commit -m "Publish public release artifacts $VERSION"
  git_with_auth push origin main
fi

if git rev-parse "refs/tags/$VERSION" >/dev/null 2>&1; then
  git tag -d "$VERSION" >/dev/null 2>&1 || true
fi
if git_with_auth ls-remote --tags origin "refs/tags/$VERSION" | grep -q "$VERSION"; then
  echo "[INFO] Tag publica $VERSION ja existe; seguindo para sincronizar a GitHub Release"
else
  git tag -a "$VERSION" -m "Release $VERSION"
  git_with_auth push origin "$VERSION"
fi

create_or_update_github_release

echo "[OK] Publicado no repo publico: $PUBLIC_REPO_URL"
echo "[OK] Versao publicada: $VERSION"
echo "[OK] GitHub Release criada/atualizada: https://github.com/$PUBLIC_REPO_SLUG/releases/tag/$VERSION"
