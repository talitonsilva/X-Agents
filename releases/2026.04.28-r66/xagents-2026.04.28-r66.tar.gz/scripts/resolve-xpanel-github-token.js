#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const BASE_DIR = '/www/server/xagents';
const DB_PATH = path.join(BASE_DIR, 'panel', 'data', 'panel.db');
const SECRET_KEY_PATH = path.join(BASE_DIR, 'runtime', 'secrets', 'agent_ssh_secret.key');

function normalizeRepoSlug(input) {
  return String(input || '')
    .trim()
    .replace(/\.git$/i, '')
    .replace(/^git@github\.com:/i, '')
    .replace(/^https?:\/\/github\.com\//i, '')
    .replace(/^\/+|\/+$/g, '');
}

function readSecretKey() {
  const raw = String(fs.readFileSync(SECRET_KEY_PATH, 'utf8') || '').trim();
  if (/^[0-9a-f]{64}$/i.test(raw)) return Buffer.from(raw, 'hex');
  return crypto.createHash('sha256').update(raw || 'xpanel-agent-ssh').digest();
}

function decryptSecret(value) {
  const text = String(value || '').trim();
  if (!text) return '';
  const parts = text.split(':');
  if (parts.length !== 4 || parts[0] !== 'v1') return text;
  const key = readSecretKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(parts[1], 'hex'));
  decipher.setAuthTag(Buffer.from(parts[2], 'hex'));
  return `${decipher.update(Buffer.from(parts[3], 'hex'), undefined, 'utf8')}${decipher.final('utf8')}`;
}

async function main() {
  const targetRepo = normalizeRepoSlug(process.argv[2] || '');
  const raw = execFileSync(
    'sqlite3',
    [
      '-separator',
      '\t',
      DB_PATH,
      `SELECT id, name, slug, config_json, secrets_enc, updated_at
       FROM ai_agent_integrations
       WHERE type = 'github' AND enabled = 1
       ORDER BY updated_at DESC, id DESC;`
    ],
    { encoding: 'utf8' }
  );
  const rows = String(raw || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [id, name, slug, configJson, secretsEnc, updatedAt] = line.split('\t');
      return {
        id,
        name,
        slug,
        config_json: configJson,
        secrets_enc: secretsEnc,
        updated_at: updatedAt
      };
    });
  const parsed = rows
    .map((row) => {
      let config = {};
      let secrets = {};
      try {
        config = JSON.parse(String(row.config_json || '{}'));
      } catch (err) {
        config = {};
      }
      try {
        secrets = JSON.parse(decryptSecret(String(row.secrets_enc || '')) || '{}');
      } catch (err) {
        secrets = {};
      }
      return {
        id: Number(row.id || 0),
        name: String(row.name || ''),
        slug: String(row.slug || ''),
        repoSlug: normalizeRepoSlug(`${config.owner || ''}/${config.repo || ''}`),
        token: String(secrets.token || secrets.accessToken || '').trim()
      };
    })
    .filter((item) => item.token);
  if (!parsed.length) process.exit(1);
  const exact = targetRepo ? parsed.find((item) => item.repoSlug === targetRepo) : null;
  process.stdout.write(String((exact || parsed[0]).token || ''));
}

main().catch(() => process.exit(1));
