#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="/www/server/xagents"
PANEL_DIR="$BASE_DIR/panel"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAGING_DIR="$(mktemp -d /tmp/xagents-upgrade.XXXXXX)"
BACKUP_DIR="$BASE_DIR/backup"
PORT="${XAGENTS_PORT:-8890}"
NODE_BIN="/usr/bin/node"
NPM_BIN="/usr/bin/npm"
STAGING_PANEL_DIR="$STAGING_DIR/src/panel"
STAGING_AGENTS_RUNTIME_ENTRY="$STAGING_PANEL_DIR/runtime/agentsRuntime.js"
STAGING_WHATSAPP_RUNTIME_ENTRY="$STAGING_PANEL_DIR/runtime/whatsappRuntime.js"
STAGING_MIGRATE_ENTRY="$STAGING_PANEL_DIR/scripts/migrate.js"
LOCAL_RELEASE_META="$BASE_DIR/release.json"
DEFAULT_REMOTE_MANIFEST_URL="${XAGENTS_REMOTE_MANIFEST_URL:-https://raw.githubusercontent.com/talitonsilva/x-agents-rep/main/manifest.json}"
STATUS_FILE="${XAGENTS_UPDATE_STATUS_FILE:-$BASE_DIR/runtime/update-status.env}"
LOG_FILE="${XAGENTS_UPDATE_LOG_FILE:-$BASE_DIR/logs/update.log}"
FORCE_UPDATE=0
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

for arg in "$@"; do
  case "$arg" in
    --force)
      FORCE_UPDATE=1
      ;;
  esac
done

mkdir -p "$(dirname "$STATUS_FILE")" "$(dirname "$LOG_FILE")" "$BACKUP_DIR"
: > "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "========================================"
echo "X-AGENTS by MasterDev Taliton Silva"
echo "Automatic Update Runtime"
echo "========================================"

sanitize_status_value() {
  printf '%s' "${1:-}" | tr '\r\n' ' ' | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//'
}

write_status() {
  local status="$1"
  local progress="$2"
  local stage="$3"
  local message="$4"
  local current_version="${5:-}"
  local remote_version="${6:-}"
  local tmp_file="${STATUS_FILE}.tmp"
  cat > "$tmp_file" <<EOF
status=$(sanitize_status_value "$status")
progress=$(sanitize_status_value "$progress")
stage=$(sanitize_status_value "$stage")
message=$(sanitize_status_value "$message")
current_version=$(sanitize_status_value "$current_version")
remote_version=$(sanitize_status_value "$remote_version")
updated_at=$(date -Iseconds)
pid=$$
EOF
  mv "$tmp_file" "$STATUS_FILE"
}

cleanup() {
  rm -rf "$STAGING_DIR"
}
trap cleanup EXIT

apt_update_base() {
  repair_system_python3 || true
  apt-get update -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"
}

apt_install_packages() {
  repair_system_python3 || true
  if ! apt-get install -y "$@"; then
    apt_update_base
    apt-get install -y "$@"
  fi
}

apt_update_single_source() {
  local source_file="$1"
  repair_system_python3 || true
  apt-get update \
    -o Dir::Etc::sourcelist="$source_file" \
    -o Dir::Etc::sourceparts="-" \
    -o APT::Get::List-Cleanup="0"
}

find_working_python() {
  local candidate=""
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] || continue
    [[ -x "$candidate" ]] || continue
    if "$candidate" -c 'import sys' >/dev/null 2>&1; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done < <(
    {
      printf '%s\n' "${PYTHON:-}"
      printf '%s\n' "${npm_config_python:-}"
      command -v python3 2>/dev/null || true
      command -v python 2>/dev/null || true
      find /usr/local/bin /usr/bin -maxdepth 1 -type f \
        \( -name 'python3' -o -name 'python3.[0-9]' -o -name 'python3.[0-9][0-9]' -o -name 'python' \) \
        2>/dev/null | sort -Vr || true
    } | awk 'NF && !seen[$0]++'
  )
  return 1
}

repair_system_python3() {
  local system_python="/usr/bin/python3"
  local system_target=""
  local fallback_python=""
  if "$system_python" -c 'import sys' >/dev/null 2>&1; then
    return 0
  fi
  system_target="$(readlink -f "$system_python" 2>/dev/null || true)"
  if [[ -n "$system_target" && -f "$system_target" ]]; then
    chown root:root "$system_target" >/dev/null 2>&1 || true
    chmod 755 "$system_target" >/dev/null 2>&1 || true
  fi
  if "$system_python" -c 'import sys' >/dev/null 2>&1; then
    return 0
  fi
  fallback_python="$(find_working_python || true)"
  if [[ -n "$fallback_python" ]]; then
    ln -sf "$fallback_python" "$system_python" >/dev/null 2>&1 || true
  fi
  "$system_python" -c 'import sys' >/dev/null 2>&1
}

ensure_native_build_toolchain() {
  if command -v make >/dev/null 2>&1 && command -v g++ >/dev/null 2>&1; then
    return 0
  fi
  apt_install_packages build-essential make g++
}

ensure_node_gyp_python() {
  local python_bin=""
  python_bin="$(find_working_python || true)"
  if [[ -z "$python_bin" ]]; then
    apt_install_packages python3 python3-venv python3-pip
    python_bin="$(find_working_python || true)"
  fi
  if [[ -z "$python_bin" ]]; then
    echo "[ERRO] Nenhum interpretador Python executavel foi encontrado para o node-gyp"
    write_status "failed" "100" "python" "Nenhum interpretador Python executavel foi encontrado para o node-gyp" "${LOCAL_VERSION:-}" "${REMOTE_VERSION:-}"
    exit 1
  fi
  export PYTHON="$python_bin"
  export npm_config_python="$python_bin"
  mkdir -p /usr/local/bin
  if ! python3 -c 'import sys' >/dev/null 2>&1; then
    ln -sf "$python_bin" /usr/local/bin/python3
    hash -r
  fi
  if ! python -c 'import sys' >/dev/null 2>&1; then
    ln -sf "$python_bin" /usr/local/bin/python
    hash -r
  fi
  echo "[INFO] Python configurado para node-gyp: $python_bin"
}

install_panel_dependencies() {
  ensure_native_build_toolchain
  ensure_node_gyp_python
  if [[ -f "$STAGING_PANEL_DIR/package-lock.json" ]]; then
    "$NPM_BIN" --prefix "$STAGING_PANEL_DIR" ci --omit=dev --legacy-peer-deps
  else
    "$NPM_BIN" --prefix "$STAGING_PANEL_DIR" install --omit=dev --legacy-peer-deps
  fi
}

ensure_sqlite3_runtime() {
  local check_cmd='require("sqlite3"); process.stdout.write("ok")'
  if (cd "$STAGING_PANEL_DIR" && "$NODE_BIN" -e "$check_cmd" >/dev/null 2>&1); then
    return 0
  fi
  echo "[INFO] Recompilando sqlite3 para compatibilidade local ..."
  "$NPM_BIN" --prefix "$STAGING_PANEL_DIR" rebuild sqlite3 --build-from-source
  (cd "$STAGING_PANEL_DIR" && "$NODE_BIN" -e "$check_cmd" >/dev/null 2>&1)
}

ensure_whisper_runtime() {
  echo "[INFO] Preparando runtime local de transcricao de audio ..."
  "$STAGING_DIR/src/scripts/bootstrap-whisper.sh"
}

ensure_node_22() {
  export DEBIAN_FRONTEND=noninteractive
  apt_install_packages curl wget ca-certificates gnupg
  local node_major=0
  if command -v "$NODE_BIN" >/dev/null 2>&1; then
    node_major="$("$NODE_BIN" -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
  elif command -v node >/dev/null 2>&1; then
    node_major="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
  fi
  if [[ "${node_major:-0}" -lt 22 ]]; then
    rm -f /etc/apt/sources.list.d/nodesource.list
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
      | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" \
      > /etc/apt/sources.list.d/nodesource.list
    apt_update_single_source /etc/apt/sources.list.d/nodesource.list
    apt-get install -y --allow-change-held-packages nodejs
  else
    apt-get install -y nodejs
  fi
  local final_major=0
  if command -v "$NODE_BIN" >/dev/null 2>&1; then
    final_major="$("$NODE_BIN" -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
  fi
  if [[ "${final_major:-0}" -lt 22 ]]; then
    echo "[ERRO] Node 22+ e obrigatorio para o X-Agents. Versao atual: $("$NODE_BIN" -v 2>/dev/null || echo 'nao encontrada')"
    write_status "failed" "100" "node" "Node 22+ e obrigatorio" "${LOCAL_VERSION:-}" "${REMOTE_VERSION:-}"
    exit 1
  fi
}

ensure_codex_cli() {
  if ! command -v "$NPM_BIN" >/dev/null 2>&1; then
    corepack enable >/dev/null 2>&1 || true
  fi
  if ! command -v "$NPM_BIN" >/dev/null 2>&1; then
    echo "[ERRO] npm nao encontrado para instalar o Codex CLI"
    write_status "failed" "100" "codex" "npm nao encontrado para instalar o Codex CLI" "${LOCAL_VERSION:-}" "${REMOTE_VERSION:-}"
    exit 1
  fi
  "$NPM_BIN" install -g @openai/codex
  hash -r
  local codex_bin=""
  local npm_prefix
  local npm_root
  npm_prefix="$("$NPM_BIN" prefix -g 2>/dev/null || true)"
  npm_root="$("$NPM_BIN" root -g 2>/dev/null || true)"
  rm -f /usr/bin/codex
  if [[ -n "${npm_prefix:-}" && -x "${npm_prefix}/bin/codex" ]]; then
    codex_bin="${npm_prefix}/bin/codex"
  elif [[ -n "${npm_prefix:-}" && -x "${npm_prefix}/node_modules/.bin/codex" ]]; then
    codex_bin="${npm_prefix}/node_modules/.bin/codex"
  elif [[ -n "${npm_root:-}" && -x "${npm_root}/@openai/codex/bin/codex.js" ]]; then
    codex_bin="${npm_root}/@openai/codex/bin/codex.js"
  fi
  if [[ -n "${codex_bin:-}" ]]; then
    ln -sf "$codex_bin" /usr/bin/codex
    export PATH="$(dirname "$codex_bin"):/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/sbin:/bin"
    hash -r
  fi
  if ! codex --version >/dev/null 2>&1; then
    echo "[ERRO] Codex CLI nao foi encontrado no PATH apos a instalacao"
    write_status "failed" "100" "codex" "Codex CLI nao foi encontrado no PATH apos a instalacao" "${LOCAL_VERSION:-}" "${REMOTE_VERSION:-}"
    exit 1
  fi
}

extract_release_field() {
  local file_path="$1"
  local field_name="$2"
  "$NODE_BIN" -e '
const fs = require("fs");
try {
  const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
  const value = data?.[process.argv[2]];
  if (value !== undefined && value !== null) process.stdout.write(String(value));
} catch (err) {}
' "$file_path" "$field_name"
}

verify_archive_checksum() {
  local archive_path="$1"
  local expected_sha256="$2"
  if [[ -z "${expected_sha256:-}" ]]; then
    return 0
  fi
  local actual_sha256
  actual_sha256="$(sha256sum "$archive_path" | awk '{print $1}')"
  if [[ "$actual_sha256" != "$expected_sha256" ]]; then
    echo "[ERRO] Checksum do pacote remoto nao confere"
    write_status "failed" "100" "download" "Checksum do pacote remoto nao confere" "$LOCAL_VERSION" "$REMOTE_VERSION"
    exit 1
  fi
}

REMOTE_MANIFEST_URL="$DEFAULT_REMOTE_MANIFEST_URL"
if [[ -f "$LOCAL_RELEASE_META" ]]; then
  saved_manifest_url="$(extract_release_field "$LOCAL_RELEASE_META" "manifestUrl")"
  if [[ -n "${saved_manifest_url:-}" ]]; then
    if [[ "$saved_manifest_url" =~ ^https://github\.com/talitonsilva/x-agents-rep/releases/download/[^/]+/manifest\.json$ ]]; then
      REMOTE_MANIFEST_URL="$DEFAULT_REMOTE_MANIFEST_URL"
    else
      REMOTE_MANIFEST_URL="$saved_manifest_url"
    fi
  fi
fi

LOCAL_VERSION=""
if [[ -f "$LOCAL_RELEASE_META" ]]; then
  LOCAL_VERSION="$(extract_release_field "$LOCAL_RELEASE_META" "version")"
fi

write_status "running" "5" "prepare" "Verificando nova versao" "$LOCAL_VERSION" ""

if [[ "$EUID" -ne 0 ]]; then
  echo "[ERRO] Execute como root"
  write_status "failed" "100" "permissions" "Execute como root" "$LOCAL_VERSION" ""
  exit 1
fi

REMOTE_MANIFEST_REQUEST_URL="$REMOTE_MANIFEST_URL"
if [[ "$REMOTE_MANIFEST_URL" == "$DEFAULT_REMOTE_MANIFEST_URL" ]]; then
  REMOTE_MANIFEST_REQUEST_URL="${REMOTE_MANIFEST_URL}?ts=$(date +%s)"
fi

curl -fsSL \
  -H "Cache-Control: no-cache" \
  -H "Pragma: no-cache" \
  "$REMOTE_MANIFEST_REQUEST_URL" \
  -o "$STAGING_DIR/manifest.json"
REMOTE_VERSION="$(extract_release_field "$STAGING_DIR/manifest.json" "version")"
REMOTE_ARCHIVE_URL="$(extract_release_field "$STAGING_DIR/manifest.json" "archiveUrl")"
REMOTE_ARCHIVE_SHA256="$(extract_release_field "$STAGING_DIR/manifest.json" "archiveSha256")"
if [[ -z "${REMOTE_ARCHIVE_URL:-}" ]]; then
  REMOTE_RELEASE_BASE_URL="$(extract_release_field "$STAGING_DIR/manifest.json" "releaseBaseUrl")"
  REMOTE_ARCHIVE_NAME="$(extract_release_field "$STAGING_DIR/manifest.json" "archive")"
  if [[ -n "${REMOTE_RELEASE_BASE_URL:-}" && -n "${REMOTE_ARCHIVE_NAME:-}" ]]; then
    REMOTE_ARCHIVE_URL="${REMOTE_RELEASE_BASE_URL}/${REMOTE_ARCHIVE_NAME}"
  fi
fi

if [[ -z "${REMOTE_VERSION:-}" || -z "${REMOTE_ARCHIVE_URL:-}" ]]; then
  echo "[ERRO] Manifest remoto invalido"
  write_status "failed" "100" "manifest" "Manifest remoto invalido" "$LOCAL_VERSION" "$REMOTE_VERSION"
  exit 1
fi

write_status "running" "10" "check" "Manifest remoto carregado" "$LOCAL_VERSION" "$REMOTE_VERSION"

if [[ "$FORCE_UPDATE" -ne 1 && -n "$LOCAL_VERSION" && "$LOCAL_VERSION" == "$REMOTE_VERSION" ]]; then
  echo "[INFO] X-AGENTS by MasterDev Taliton Silva ja esta na versao mais recente ($LOCAL_VERSION)"
  write_status "no_update" "100" "check" "X-AGENTS by MasterDev Taliton Silva ja esta na versao mais recente" "$LOCAL_VERSION" "$REMOTE_VERSION"
  exit 0
fi

ensure_node_22
ensure_codex_cli
apt_install_packages build-essential python3 python3-venv python3-pip ffmpeg make g++ certbot python3-certbot-dns-cloudflare python3-certbot-nginx python3-certbot-apache openssh-client jq

write_status "running" "20" "download" "Baixando pacote da nova versao" "$LOCAL_VERSION" "$REMOTE_VERSION"
curl -fsSL "$REMOTE_ARCHIVE_URL" -o "$STAGING_DIR/xagents.tar.gz"
verify_archive_checksum "$STAGING_DIR/xagents.tar.gz" "$REMOTE_ARCHIVE_SHA256"

write_status "running" "30" "extract" "Extraindo pacote da nova versao" "$LOCAL_VERSION" "$REMOTE_VERSION"
mkdir -p "$STAGING_DIR/src"
tar -xzf "$STAGING_DIR/xagents.tar.gz" -C "$STAGING_DIR/src"

write_status "running" "45" "backup" "Gerando backup antes da atualizacao" "$LOCAL_VERSION" "$REMOTE_VERSION"
BACKUP_FILE="$BACKUP_DIR/xagents_preupdate_$(date +%Y%m%d_%H%M%S).tar.gz"
BACKUP_TIMEOUT_SECONDS="${XAGENTS_BACKUP_TIMEOUT_SECONDS:-180}"
BACKUP_TARGETS=(
  "release.json"
  "panel/data/panel.db"
  "runtime/agents"
  "runtime/update-status.env"
  "runtime/whatsapp"
)
BACKUP_EXCLUDES=(
  "--exclude=runtime/whatsapp/media"
  "--exclude=runtime/whatsapp/cache"
  "--exclude=runtime/whatsapp/transcripts"
  "--exclude=runtime/agents/tmp"
)
BACKUP_CMD=(tar -czf "$BACKUP_FILE" -C "$BASE_DIR")
BACKUP_CMD+=("${BACKUP_EXCLUDES[@]}")
BACKUP_CMD+=("${BACKUP_TARGETS[@]}")
if command -v timeout >/dev/null 2>&1; then
  if ! timeout "${BACKUP_TIMEOUT_SECONDS}s" "${BACKUP_CMD[@]}" 2>/dev/null; then
    echo "[WARN] Backup de dados criticos excedeu ${BACKUP_TIMEOUT_SECONDS}s ou falhou; seguindo update sem bloquear."
    rm -f "$BACKUP_FILE" 2>/dev/null || true
  fi
else
  "${BACKUP_CMD[@]}" 2>/dev/null || {
    echo "[WARN] Backup de dados criticos falhou; seguindo update sem bloquear."
    rm -f "$BACKUP_FILE" 2>/dev/null || true
  }
fi

write_status "running" "55" "dependencies" "Instalando dependencias da nova versao" "$LOCAL_VERSION" "$REMOTE_VERSION"
install_panel_dependencies
ensure_sqlite3_runtime
write_status "running" "64" "transcription" "Preparando runtime de transcricao" "$LOCAL_VERSION" "$REMOTE_VERSION"
ensure_whisper_runtime

write_status "running" "72" "validate" "Validando arquivos da nova versao" "$LOCAL_VERSION" "$REMOTE_VERSION"
"$NODE_BIN" --check "$STAGING_PANEL_DIR/server.js"
"$NODE_BIN" --check "$STAGING_AGENTS_RUNTIME_ENTRY"
"$NODE_BIN" --check "$STAGING_WHATSAPP_RUNTIME_ENTRY"
"$NODE_BIN" --check "$STAGING_MIGRATE_ENTRY"
"$NODE_BIN" --check "$STAGING_PANEL_DIR/public/js/app.js"
if [[ -f "$STAGING_PANEL_DIR/public/js/docs.js" ]]; then
  "$NODE_BIN" --check "$STAGING_PANEL_DIR/public/js/docs.js"
fi

write_status "running" "82" "sync" "Aplicando nova versao no servidor" "$LOCAL_VERSION" "$REMOTE_VERSION"
rsync -a --delete \
  --exclude /logs/ \
  --exclude /runtime/ \
  --exclude /backup/ \
  --exclude /tmp/ \
  --exclude /ssl/ \
  --exclude /release/ \
  --exclude panel/data/panel.db \
  "$STAGING_DIR/src/" "$BASE_DIR/"

chmod +x "$BASE_DIR/scripts/"*.sh 2>/dev/null || true
if [[ -f "$BASE_DIR/scripts/xag.sh" ]]; then
  chmod +x "$BASE_DIR/scripts/xag.sh"
  ln -sf "$BASE_DIR/scripts/xag.sh" /usr/local/bin/xag
fi

write_status "running" "92" "finalize" "Finalizando atualizacao antes do restart do painel" "$LOCAL_VERSION" "$REMOTE_VERSION"
systemctl daemon-reload
systemctl restart xagents-update.timer

echo "X-AGENTS by MasterDev Taliton Silva atualizado com sucesso em :${PORT}"
write_status "completed" "100" "done" "Atualizacao concluida com sucesso. Reiniciando painel" "$REMOTE_VERSION" "$REMOTE_VERSION"
sleep 1
systemctl restart xagents.service
