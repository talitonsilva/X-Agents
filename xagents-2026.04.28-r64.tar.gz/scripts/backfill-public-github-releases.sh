#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PUBLIC_REPO_URL="${XPANEL_PUBLIC_REPO_URL:-https://github.com/talitonsilva/X-Agents.git}"
DIST_ROOT="$SRC_DIR/release/dist"
WORK_DIR="$(mktemp -d /tmp/xagents-public-backfill.XXXXXX)"
API_TMP_DIR="$(mktemp -d /tmp/xagents-public-backfill-api.XXXXXX)"

cleanup() {
  rm -rf "$WORK_DIR" "$API_TMP_DIR"
}

trap cleanup EXIT

resolve_repo_slug() {
  local url="$1"
  local normalized="${url%.git}"
  normalized="${normalized#git@github.com:}"
  normalized="${normalized#https://github.com/}"
  normalized="${normalized#http://github.com/}"
  printf '%s' "$normalized"
}

resolve_github_token() {
  if [[ -n "${XPANEL_GITHUB_TOKEN:-}" ]]; then
    printf '%s' "$XPANEL_GITHUB_TOKEN"
    return 0
  fi
  if [[ -n "${GITHUB_TOKEN:-}" ]]; then
    printf '%s' "$GITHUB_TOKEN"
    return 0
  fi
  if [[ -n "${GH_TOKEN:-}" ]]; then
    printf '%s' "$GH_TOKEN"
    return 0
  fi
  local credential_output
  credential_output="$(printf 'protocol=https\nhost=github.com\n\n' | git credential fill 2>/dev/null || true)"
  local token
  token="$(printf '%s\n' "$credential_output" | awk -F= '/^password=/{print $2; exit}')"
  if [[ -n "$token" ]]; then
    printf '%s' "$token"
    return 0
  fi
  return 1
}

github_api_request() {
  local method="$1"
  local url="$2"
  local output_file="$3"
  local data_file="${4:-}"
  local content_type="${5:-application/json}"
  local http_code
  if [[ -n "$data_file" ]]; then
    http_code="$(
      curl -sS \
        -X "$method" \
        -H "Authorization: Bearer $GITHUB_TOKEN_VALUE" \
        -H "Accept: application/vnd.github+json" \
        -H "X-GitHub-Api-Version: 2022-11-28" \
        -H "Content-Type: $content_type" \
        --data-binary "@$data_file" \
        -o "$output_file" \
        -w "%{http_code}" \
        "$url"
    )"
  else
    http_code="$(
      curl -sS \
        -X "$method" \
        -H "Authorization: Bearer $GITHUB_TOKEN_VALUE" \
        -H "Accept: application/vnd.github+json" \
        -H "X-GitHub-Api-Version: 2022-11-28" \
        -o "$output_file" \
        -w "%{http_code}" \
        "$url"
    )"
  fi
  printf '%s' "$http_code"
}

json_field() {
  local file="$1"
  local expr="$2"
  node -e '
    const fs = require("fs");
    const file = process.argv[1];
    const expr = process.argv[2];
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    const value = expr.split(".").reduce((acc, key) => (acc && key ? acc[key] : acc), data);
    if (value === undefined || value === null) process.exit(1);
    if (typeof value === "object") process.stdout.write(JSON.stringify(value));
    else process.stdout.write(String(value));
  ' "$file" "$expr"
}

delete_release_asset_if_exists() {
  local release_json="$1"
  local asset_name="$2"
  local asset_id
  asset_id="$(
    node -e '
      const fs = require("fs");
      const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
      const assetName = process.argv[2];
      const asset = Array.isArray(data.assets) ? data.assets.find((item) => item && item.name === assetName) : null;
      if (asset && asset.id) process.stdout.write(String(asset.id));
    ' "$release_json" "$asset_name"
  )"
  if [[ -z "$asset_id" ]]; then
    return 0
  fi
  local delete_out="$API_TMP_DIR/delete-${asset_id}.json"
  local delete_code
  delete_code="$(github_api_request DELETE "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases/assets/$asset_id" "$delete_out")"
  if [[ "$delete_code" != "204" ]]; then
    echo "[ERRO] Falha ao remover asset antigo $asset_name"
    cat "$delete_out"
    exit 1
  fi
}

upload_release_asset() {
  local release_json="$1"
  local file_path="$2"
  local asset_name
  asset_name="$(basename "$file_path")"
  delete_release_asset_if_exists "$release_json" "$asset_name"
  local upload_url
  upload_url="$(json_field "$release_json" "upload_url")"
  upload_url="${upload_url%\{*}"
  upload_url="${upload_url}?name=${asset_name}"
  local mime_type="application/octet-stream"
  case "$asset_name" in
    *.json) mime_type="application/json" ;;
    *.sh) mime_type="text/x-shellscript" ;;
    *.tar.gz) mime_type="application/gzip" ;;
  esac
  local upload_out="$API_TMP_DIR/upload-${asset_name}.json"
  local upload_code
  upload_code="$(github_api_request POST "$upload_url" "$upload_out" "$file_path" "$mime_type")"
  if [[ "$upload_code" != "201" ]]; then
    echo "[ERRO] Falha ao subir asset $asset_name"
    cat "$upload_out"
    exit 1
  fi
}

ensure_github_release() {
  local version="$1"
  local release_get_out="$API_TMP_DIR/release-${version}.json"
  local get_code
  get_code="$(github_api_request GET "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases/tags/$version" "$release_get_out")"
  if [[ "$get_code" == "404" ]]; then
    local create_payload="$API_TMP_DIR/create-${version}.json"
    cat > "$create_payload" <<EOF
{
  "tag_name": "$version",
  "target_commitish": "main",
  "name": "$version",
  "body": "Release historica restaurada automaticamente: $version",
  "draft": false,
  "prerelease": false,
  "generate_release_notes": false
}
EOF
    local create_out="$API_TMP_DIR/create-${version}.out.json"
    local create_code
    create_code="$(github_api_request POST "https://api.github.com/repos/$PUBLIC_REPO_SLUG/releases" "$create_out" "$create_payload")"
    if [[ "$create_code" != "201" ]]; then
      echo "[ERRO] Falha ao criar release $version"
      cat "$create_out"
      exit 1
    fi
    cp "$create_out" "$release_get_out"
  elif [[ "$get_code" != "200" ]]; then
    echo "[ERRO] Falha ao consultar release $version"
    cat "$release_get_out"
    exit 1
  fi

  upload_release_asset "$release_get_out" "$DIST_ROOT/$version/xagents-$version.tar.gz"
  upload_release_asset "$release_get_out" "$DIST_ROOT/$version/install.sh"
  upload_release_asset "$release_get_out" "$DIST_ROOT/$version/manifest.json"
}

PUBLIC_REPO_SLUG="$(resolve_repo_slug "$PUBLIC_REPO_URL")"
GITHUB_TOKEN_VALUE="$(resolve_github_token || true)"
if [[ -z "$GITHUB_TOKEN_VALUE" ]]; then
  echo "[ERRO] Token GitHub nao encontrado"
  exit 1
fi

git clone "$PUBLIC_REPO_URL" "$WORK_DIR/repo" >/dev/null 2>&1
cd "$WORK_DIR/repo"
git checkout main >/dev/null 2>&1 || true
git fetch --tags origin >/dev/null 2>&1 || true

mapfile -t versions < <(find "$DIST_ROOT" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort)

for version in "${versions[@]}"; do
  [[ "$version" == "dev" ]] && continue
  [[ -f "$DIST_ROOT/$version/xagents-$version.tar.gz" ]] || continue
  [[ -f "$DIST_ROOT/$version/install.sh" ]] || continue
  [[ -f "$DIST_ROOT/$version/manifest.json" ]] || continue

  if ! git rev-parse "refs/tags/$version" >/dev/null 2>&1; then
    commit_sha="$(git log --all --grep="Publish public release artifacts $version" --format='%H' -n 1 || true)"
    if [[ -z "$commit_sha" ]]; then
      echo "[WARN] Sem tag e sem commit historico local para $version; pulando"
      continue
    fi
    git tag -a "$version" -m "Release $version" "$commit_sha"
    git push origin "$version"
  fi

  ensure_github_release "$version"
  echo "[OK] Release historica garantida: $version"
done
