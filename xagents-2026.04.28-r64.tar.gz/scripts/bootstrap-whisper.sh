#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="/www/server/xagents"
WHISPER_DIR="$BASE_DIR/runtime/whisper"
VENV_DIR="$WHISPER_DIR/venv"
PYTHON_BIN="${PYTHON_BIN:-python3}"
PIP_EXTRA_INDEX_URL="${PIP_EXTRA_INDEX_URL:-}"

export DEBIAN_FRONTEND=noninteractive
export PATH="/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/sbin:/bin:${PATH:-}"

apt_update_base() {
  apt-get update -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"
}

apt_install_packages() {
  if ! apt-get install -y "$@"; then
    apt_update_base
    apt-get install -y "$@"
  fi
}

ensure_system_packages() {
  apt_install_packages ffmpeg python3 python3-venv python3-pip
}

ensure_venv() {
  mkdir -p "$WHISPER_DIR"
  if [[ ! -x "$VENV_DIR/bin/python3" ]]; then
    "$PYTHON_BIN" -m venv "$VENV_DIR"
  fi
}

install_whisper_runtime() {
  local pip_bin="$VENV_DIR/bin/pip"
  "$pip_bin" install --upgrade pip setuptools wheel
  if [[ -n "$PIP_EXTRA_INDEX_URL" ]]; then
    "$pip_bin" install --upgrade openai-whisper --extra-index-url "$PIP_EXTRA_INDEX_URL"
    return
  fi
  "$pip_bin" install --upgrade openai-whisper
}

verify_runtime() {
  "$VENV_DIR/bin/python3" - <<'PY'
import importlib
import shutil

if shutil.which("ffmpeg") is None:
    raise SystemExit("ffmpeg not found")
importlib.import_module("whisper")
print("ok")
PY
}

ensure_system_packages
ensure_venv
install_whisper_runtime
verify_runtime >/dev/null
