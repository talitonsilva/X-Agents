#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="${XAGENTS_BASE_DIR:-/www/server/xagents}"
PANEL_DIR="$BASE_DIR/panel"
RELEASE_META_PATH="$BASE_DIR/release.json"
UPDATE_STATUS_PATH="$BASE_DIR/runtime/update-status.env"
UPDATE_LOG_PATH="$BASE_DIR/logs/update.log"
SERVICE_NAME="xagents.service"
UPDATE_SERVICE_NAME="xagents-update.service"
UPDATE_TIMER_NAME="xagents-update.timer"
PORT="${XAGENTS_PORT:-8890}"
DEFAULT_URL="http://127.0.0.1:${PORT}"
NODE_BIN="${NODE_BIN:-$(command -v node || true)}"
CURL_BIN="${CURL_BIN:-$(command -v curl || true)}"

has_cmd() {
  command -v "$1" >/dev/null 2>&1
}

is_tty() {
  [[ -t 0 && -t 1 ]]
}

panel_url() {
  printf '%s\n' "${XAG_URL:-$DEFAULT_URL}"
}

panel_ip() {
  hostname -I 2>/dev/null | awk '{print $1}'
}

panel_public_url() {
  local ip
  ip="$(panel_ip)"
  if [[ -n "${ip:-}" ]]; then
    printf 'http://%s:%s\n' "$ip" "$PORT"
  else
    panel_url
  fi
}

require_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "[ERRO] Este comando exige root."
    exit 1
  fi
}

print_usage() {
  cat <<EOF
X-Agents CLI

Uso:
  xag                     Abre o menu interativo quando houver TTY
  xag help                Mostra esta ajuda
  xag status              Resume versao, URLs, servicos e health
  xag doctor              Mostra diagnostico de runtime local
  xag start               Inicia xagents.service
  xag stop                Para xagents.service
  xag restart             Reinicia xagents.service
  xag logs [panel|update] [-f]
  xag update [--force]
  xag health
  xag version
  xag url
  xag docs
  xag api METHOD PATH [-d JSON] [-u USER] [-p PASS] [-H HOST]

Exemplos:
  xag
  xag status
  xag logs -f
  xag logs update -f
  xag update --force
  XAG_USER=admin XAG_PASS='senha' xag api GET /api/agents/bootstrap
  XAG_USER=admin XAG_PASS='senha' xag api POST /api/agents/tasks -d '{"agentId":1,"prompt":"Revise o projeto"}'
EOF
}

print_api_help() {
  cat <<EOF
Uso:
  xag api METHOD PATH [-d JSON] [-u USER] [-p PASS] [-H HOST]

Notas:
  - PATH pode ser relativo, ex.: /api/agents/bootstrap
  - HOST padrao: ${DEFAULT_URL}
  - USER padrao: XAG_USER ou admin
  - PASS padrao: XAG_PASS; se ausente e houver TTY, sera pedido no prompt
  - Em mutacoes, o comando cuida de login, cookie de sessao e CSRF

Exemplos:
  xag api GET /api/me
  xag api GET /api/agents/bootstrap
  xag api POST /api/agents/tasks -d '{"agentId":1,"prompt":"Analise o repositorio"}'
  xag api POST /api/agents/tasks/1/continue -d '{"prompt":"Continue do ponto anterior"}'
  xag api POST /api/agents/plans -d '{"name":"Daily review","agentId":1,"type":"maintenance","executionMode":"continue_plan_thread","scheduleMode":"daily","runAt":"2026-04-01T09:00:00","timezone":"Europe/Berlin","briefText":"Revisar pendencias"}'
EOF
}

json_file_field() {
  local file_path="$1"
  local field_name="$2"
  if [[ ! -f "$file_path" ]]; then
    return 0
  fi
  if [[ -n "${NODE_BIN:-}" && -x "${NODE_BIN:-}" ]]; then
    "$NODE_BIN" -e '
const fs = require("fs");
try {
  const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
  const value = data?.[process.argv[2]];
  if (value !== undefined && value !== null) process.stdout.write(String(value));
} catch (err) {}
' "$file_path" "$field_name"
    return 0
  fi
  sed -n "s/.*\"${field_name}\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\\1/p" "$file_path" | head -n 1
}

current_version() {
  local value
  value="$(json_file_field "$RELEASE_META_PATH" "version")"
  if [[ -n "${value:-}" ]]; then
    printf '%s\n' "$value"
    return 0
  fi
  if [[ -f "$BASE_DIR/VERSION" ]]; then
    cat "$BASE_DIR/VERSION"
    return 0
  fi
  printf '\n'
}

status_file_field() {
  local field_name="$1"
  if [[ ! -f "$UPDATE_STATUS_PATH" ]]; then
    return 0
  fi
  sed -n "s/^${field_name}=//p" "$UPDATE_STATUS_PATH" | head -n 1
}

pretty_print_file() {
  local file_path="$1"
  if [[ ! -s "$file_path" ]]; then
    return 0
  fi
  if [[ -n "${NODE_BIN:-}" && -x "${NODE_BIN:-}" ]]; then
    "$NODE_BIN" -e '
const fs = require("fs");
const input = fs.readFileSync(process.argv[1], "utf8");
try {
  process.stdout.write(`${JSON.stringify(JSON.parse(input), null, 2)}\n`);
} catch (err) {
  process.stdout.write(input.endsWith("\n") ? input : `${input}\n`);
}
' "$file_path"
    return 0
  fi
  cat "$file_path"
  printf '\n'
}

service_state() {
  if ! has_cmd systemctl; then
    printf 'systemctl-unavailable\n'
    return 0
  fi
  local value
  value="$(systemctl is-active "$1" 2>/dev/null || true)"
  printf '%s\n' "${value:-unknown}"
}

service_enabled_state() {
  if ! has_cmd systemctl; then
    printf 'systemctl-unavailable\n'
    return 0
  fi
  local value
  value="$(systemctl is-enabled "$1" 2>/dev/null || true)"
  printf '%s\n' "${value:-unknown}"
}

show_urls() {
  cat <<EOF
Panel URL (local): $(panel_url)
Panel URL (host IP): $(panel_public_url)
Docs URL: $(panel_public_url)/docs
Health URL: $(panel_url)/healthz
Docs file: $PANEL_DIR/public/docs.html
EOF
}

show_status() {
  local version update_status update_stage update_message health_file health_code
  version="$(current_version)"
  update_status="$(status_file_field "status")"
  update_stage="$(status_file_field "stage")"
  update_message="$(status_file_field "message")"
  printf 'X-Agents Status\n'
  printf 'Version: %s\n' "${version:-unknown}"
  show_urls
  printf 'Panel service: %s (%s)\n' "$(service_state "$SERVICE_NAME")" "$(service_enabled_state "$SERVICE_NAME")"
  printf 'Update service: %s\n' "$(service_state "$UPDATE_SERVICE_NAME")"
  printf 'Update timer: %s (%s)\n' "$(service_state "$UPDATE_TIMER_NAME")" "$(service_enabled_state "$UPDATE_TIMER_NAME")"
  if [[ -n "${update_status:-}" || -n "${update_stage:-}" || -n "${update_message:-}" ]]; then
    printf 'Update snapshot: status=%s stage=%s message=%s\n' "${update_status:-n/a}" "${update_stage:-n/a}" "${update_message:-n/a}"
  fi

  if [[ -n "${CURL_BIN:-}" && -x "${CURL_BIN:-}" ]]; then
    health_file="$(mktemp)"
    if health_code="$("$CURL_BIN" -sS -o "$health_file" -w "%{http_code}" "$(panel_url)/healthz" 2>/dev/null)"; then
      printf 'Health HTTP: %s\n' "$health_code"
      pretty_print_file "$health_file"
    else
      printf 'Health HTTP: unavailable\n'
    fi
    rm -f "$health_file"
  else
    printf 'Health HTTP: curl nao encontrado\n'
  fi
}

show_doctor() {
  local node_version npm_version codex_version
  node_version="$(command -v node >/dev/null 2>&1 && node -v 2>/dev/null || printf 'missing')"
  npm_version="$(command -v npm >/dev/null 2>&1 && npm -v 2>/dev/null || printf 'missing')"
  codex_version="$(command -v codex >/dev/null 2>&1 && codex --version 2>/dev/null || printf 'missing')"
  cat <<EOF
X-Agents Doctor
Base dir: $BASE_DIR
Panel dir: $PANEL_DIR
Node: $node_version
npm: $npm_version
Codex CLI: $codex_version
curl: $(command -v curl 2>/dev/null || printf 'missing')
systemctl: $(command -v systemctl 2>/dev/null || printf 'missing')
Release meta: $(if [[ -f "$RELEASE_META_PATH" ]]; then printf 'present'; else printf 'missing'; fi)
Update status file: $(if [[ -f "$UPDATE_STATUS_PATH" ]]; then printf 'present'; else printf 'missing'; fi)
Update log: $(if [[ -f "$UPDATE_LOG_PATH" ]]; then printf 'present'; else printf 'missing'; fi)
EOF
}

service_action() {
  local action="$1"
  require_root
  if ! has_cmd systemctl; then
    echo "[ERRO] systemctl nao encontrado."
    exit 1
  fi
  systemctl "$action" "$SERVICE_NAME"
  printf 'xagents.service %s executado.\n' "$action"
}

show_logs() {
  local target="panel"
  local follow=0
  while [[ $# -gt 0 ]]; do
    case "$1" in
      panel|update)
        target="$1"
        shift
        ;;
      -f|--follow)
        follow=1
        shift
        ;;
      *)
        echo "[ERRO] Argumento invalido para logs: $1"
        exit 1
        ;;
    esac
  done

  if [[ "$target" == "update" ]]; then
    if [[ -f "$UPDATE_LOG_PATH" ]]; then
      if [[ "$follow" -eq 1 ]]; then
        tail -n 120 -f "$UPDATE_LOG_PATH"
      else
        tail -n 120 "$UPDATE_LOG_PATH"
      fi
      return 0
    fi
    if has_cmd journalctl; then
      if [[ "$follow" -eq 1 ]]; then
        journalctl -u "$UPDATE_SERVICE_NAME" -n 120 -f
      else
        journalctl -u "$UPDATE_SERVICE_NAME" -n 120
      fi
      return 0
    fi
    echo "[ERRO] Nenhum log de update encontrado."
    exit 1
  fi

  if has_cmd journalctl; then
    if [[ "$follow" -eq 1 ]]; then
      journalctl -u "$SERVICE_NAME" -n 120 -f
    else
      journalctl -u "$SERVICE_NAME" -n 120
    fi
    return 0
  fi

  echo "[ERRO] journalctl nao encontrado."
  exit 1
}

run_health() {
  if [[ -z "${CURL_BIN:-}" || ! -x "${CURL_BIN:-}" ]]; then
    echo "[ERRO] curl nao encontrado."
    exit 1
  fi
  "$CURL_BIN" -fsSL "$(panel_url)/healthz"
  printf '\n'
}

run_update() {
  local force=0
  require_root
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --force)
        force=1
        shift
        ;;
      *)
        echo "[ERRO] Argumento invalido para update: $1"
        exit 1
        ;;
    esac
  done

  local cmd=(/usr/bin/bash "$BASE_DIR/scripts/update.sh")
  if [[ "$force" -eq 1 ]]; then
    cmd+=(--force)
  fi
  nohup "${cmd[@]}" >/dev/null 2>&1 &
  printf 'Update iniciado em background. Acompanhe com: xag logs update -f\n'
}

build_login_payload() {
  local username="$1"
  local password="$2"
  if [[ -z "${NODE_BIN:-}" || ! -x "${NODE_BIN:-}" ]]; then
    echo "[ERRO] node nao encontrado para serializar payload JSON."
    exit 1
  fi
  "$NODE_BIN" -e 'process.stdout.write(JSON.stringify({ username: process.argv[1], password: process.argv[2] }));' "$username" "$password"
}

read_request_data() {
  local raw="$1"
  if [[ "$raw" == "@-" ]]; then
    cat
    return 0
  fi
  if [[ "$raw" == @* ]]; then
    cat "${raw#@}"
    return 0
  fi
  printf '%s' "$raw"
}

ensure_api_password() {
  local password="$1"
  if [[ -n "$password" ]]; then
    printf '%s' "$password"
    return 0
  fi
  if is_tty; then
    local prompted=""
    read -r -s -p "X-Agents password: " prompted
    printf '\n' >&2
    printf '%s' "$prompted"
    return 0
  fi
  echo "[ERRO] Informe a senha com -p/--pass ou XAG_PASS." >&2
  exit 1
}

api_request() {
  local method="" request_path="" data="" host="${XAG_URL:-$DEFAULT_URL}" user="${XAG_USER:-admin}" pass="${XAG_PASS:-}"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -u|--user)
        user="${2:-}"
        shift 2
        ;;
      -p|--pass)
        pass="${2:-}"
        shift 2
        ;;
      -H|--host)
        host="${2:-}"
        shift 2
        ;;
      -d|--data|--json)
        data="$(read_request_data "${2:-}")"
        shift 2
        ;;
      -h|--help)
        print_api_help
        return 0
        ;;
      *)
        if [[ -z "$method" ]]; then
          method="$(printf '%s' "$1" | tr '[:lower:]' '[:upper:]')"
          shift
          continue
        fi
        if [[ -z "$request_path" ]]; then
          request_path="$1"
          shift
          continue
        fi
        echo "[ERRO] Argumento invalido para xag api: $1" >&2
        exit 1
        ;;
    esac
  done

  if [[ -z "$method" || -z "$request_path" ]]; then
    print_api_help
    exit 1
  fi

  pass="$(ensure_api_password "$pass")"
  if [[ "$request_path" != http://* && "$request_path" != https://* ]]; then
    if [[ "$request_path" != /* ]]; then
      request_path="/$request_path"
    fi
    request_path="${host%/}${request_path}"
  fi

  local cookie_file login_file csrf_file response_file login_status csrf_status request_status csrf_token=""
  cookie_file="$(mktemp)"
  login_file="$(mktemp)"
  response_file="$(mktemp)"
  trap 'rm -f "$cookie_file" "$login_file" "${csrf_file:-}" "$response_file"' RETURN

  if [[ -z "${CURL_BIN:-}" || ! -x "${CURL_BIN:-}" ]]; then
    echo "[ERRO] curl nao encontrado." >&2
    exit 1
  fi

  if ! login_status="$("$CURL_BIN" -sS -o "$login_file" -w "%{http_code}" \
    -c "$cookie_file" \
    -H "Content-Type: application/json" \
    -X POST "${host%/}/api/login" \
    --data "$(build_login_payload "$user" "$pass")")"; then
    echo "[ERRO] Falha de rede ao fazer login." >&2
    exit 1
  fi
  if [[ "$login_status" -lt 200 || "$login_status" -ge 300 ]]; then
    pretty_print_file "$login_file" >&2
    exit 1
  fi

  if [[ "$method" != "GET" && "$method" != "HEAD" && "$method" != "OPTIONS" ]]; then
    csrf_file="$(mktemp)"
    if ! csrf_status="$("$CURL_BIN" -sS -o "$csrf_file" -w "%{http_code}" -b "$cookie_file" "${host%/}/api/csrf")"; then
      echo "[ERRO] Falha ao obter CSRF." >&2
      exit 1
    fi
    if [[ "$csrf_status" -lt 200 || "$csrf_status" -ge 300 ]]; then
      pretty_print_file "$csrf_file" >&2
      exit 1
    fi
    if [[ -n "${NODE_BIN:-}" && -x "${NODE_BIN:-}" ]]; then
      csrf_token="$("$NODE_BIN" -e '
const fs = require("fs");
try {
  const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
  process.stdout.write(String(data.csrfToken || ""));
} catch (err) {}
' "$csrf_file")"
    fi
  fi

  local curl_args=(-sS -o "$response_file" -w "%{http_code}" -b "$cookie_file" -X "$method")
  if [[ -n "$csrf_token" ]]; then
    curl_args+=(-H "x-csrf-token: $csrf_token")
  fi
  if [[ -n "$data" ]]; then
    curl_args+=(-H "Content-Type: application/json" --data "$data")
  fi
  curl_args+=("$request_path")

  if ! request_status="$("$CURL_BIN" "${curl_args[@]}")"; then
    echo "[ERRO] Falha de rede ao chamar a API." >&2
    exit 1
  fi

  pretty_print_file "$response_file"
  if [[ "$request_status" -lt 200 || "$request_status" -ge 300 ]]; then
    exit 1
  fi
}

pause_if_tty() {
  if is_tty; then
    read -r -p "Pressione ENTER para continuar..." _
  fi
}

show_docs_help() {
  cat <<EOF
Docs URL: $(panel_public_url)/docs
Panel URL: $(panel_public_url)
CLI examples:
  xag
  xag status
  xag logs -f
  XAG_USER=admin XAG_PASS='senha' xag api GET /api/agents/bootstrap
EOF
}

interactive_menu() {
  while true; do
    cat <<EOF

X-Agents Interactive Menu
1) Status
2) Doctor
3) Restart panel
4) Start panel
5) Stop panel
6) Panel logs
7) Update logs
8) Health check
9) Run update
10) Docs and URLs
11) API examples
0) Exit
EOF
    read -r -p "Choose an option: " choice
    case "$choice" in
      1)
        show_status
        pause_if_tty
        ;;
      2)
        show_doctor
        pause_if_tty
        ;;
      3)
        service_action restart
        pause_if_tty
        ;;
      4)
        service_action start
        pause_if_tty
        ;;
      5)
        service_action stop
        pause_if_tty
        ;;
      6)
        show_logs panel -f
        ;;
      7)
        show_logs update -f
        ;;
      8)
        run_health
        pause_if_tty
        ;;
      9)
        run_update
        pause_if_tty
        ;;
      10)
        show_docs_help
        pause_if_tty
        ;;
      11)
        print_api_help
        pause_if_tty
        ;;
      0)
        exit 0
        ;;
      *)
        echo "Opcao invalida."
        ;;
    esac
  done
}

main() {
  local command="${1:-}"
  if [[ -z "$command" ]]; then
    if is_tty; then
      interactive_menu
      exit 0
    fi
    print_usage
    exit 0
  fi

  shift || true
  case "$command" in
    help|-h|--help)
      print_usage
      ;;
    status)
      show_status
      ;;
    doctor)
      show_doctor
      ;;
    start|stop|restart)
      service_action "$command"
      ;;
    logs)
      show_logs "$@"
      ;;
    update)
      run_update "$@"
      ;;
    health)
      run_health
      ;;
    version)
      printf '%s\n' "$(current_version)"
      ;;
    url)
      show_urls
      ;;
    docs)
      show_docs_help
      ;;
    api)
      api_request "$@"
      ;;
    *)
      echo "[ERRO] Comando desconhecido: $command" >&2
      print_usage
      exit 1
      ;;
  esac
}

main "$@"
