#!/usr/bin/env python3
import json
import os
import sys


def main():
    if len(sys.argv) < 4:
        print(json.dumps({"ok": False, "error": "usage: aapanel-issue-panel-ssl.py <domain> <webroot> <email>"}))
        return 1

    domain = str(sys.argv[1]).strip().lower()
    webroot = os.path.abspath(str(sys.argv[2]).strip())
    email = str(sys.argv[3]).strip().lower()
    if not domain or not webroot or not email:
        print(json.dumps({"ok": False, "error": "domain, webroot and email are required"}))
        return 1

    os.chdir('/www/server/panel')
    if 'class/' not in sys.path:
        sys.path.insert(0, 'class/')

    import public  # type: ignore
    import acme_v2  # type: ignore

    os.makedirs(os.path.join(webroot, '.well-known', 'acme-challenge'), exist_ok=True)
    public.M('users').where('id=?', (1,)).setField('email', email)

    result = acme_v2.acme_v2().apply_cert([domain], 'http', webroot)
    if not result.get('status'):
      print(json.dumps({
          "ok": False,
          "error": result.get('msg') or 'SSL issuance failed',
          "result": result
      }))
      return 1

    cert_dir = os.path.join('/www/server/panel/vhost/cert', domain)
    os.makedirs(cert_dir, exist_ok=True)
    fullchain = "{}{}".format(result.get('cert', ''), result.get('root', ''))
    privkey = result.get('private_key', '')
    public.writeFile(os.path.join(cert_dir, 'fullchain.pem'), fullchain)
    public.writeFile(os.path.join(cert_dir, 'privkey.pem'), privkey)
    public.writeFile(os.path.join(cert_dir, 'info.json'), json.dumps({
        "issuer": "Let's Encrypt",
        "domain": domain,
        "email": email
    }))

    print(json.dumps({
        "ok": True,
        "domain": domain,
        "webroot": webroot,
        "certPath": cert_dir
    }))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
